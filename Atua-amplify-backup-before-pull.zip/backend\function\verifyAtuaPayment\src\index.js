"use strict";

/* Amplify Params - DO NOT EDIT
    API_ATUA_GRAPHQLAPIENDPOINTOUTPUT
    API_ATUA_GRAPHQLAPIIDOUTPUT
    API_ATUA_GRAPHQLAPIKEYOUTPUT
    ENV
    REGION
 Amplify Params - DO NOT EDIT */

const { SSMClient, GetParameterCommand } = require("@aws-sdk/client-ssm");

const https = require("https");
const crypto = require("crypto");

const { saveReusablePaymentMethod } = require("./paymentMethodHelper");

/* ==========================================================
   CONFIGURATION
========================================================== */

const GRAPHQL_ENDPOINT = process.env.API_ATUA_GRAPHQLAPIENDPOINTOUTPUT;

const GRAPHQL_API_KEY = process.env.API_ATUA_GRAPHQLAPIKEYOUTPUT;

const REGION = process.env.REGION || process.env.AWS_REGION;

/* ==========================================================
   GET PAYSTACK SECRET
========================================================== */

const getPaystackSecretKey = async () => {
  const parameterName = process.env.PAYSTACK_SECRET_KEY;

  if (!parameterName) {
    throw new Error("PAYSTACK_SECRET_KEY secret is not configured.");
  }

  const ssmClient = new SSMClient({
    region: REGION,
  });

  const command = new GetParameterCommand({
    Name: parameterName,
    WithDecryption: true,
  });

  const result = await ssmClient.send(command);

  const secretKey = result?.Parameter?.Value;

  if (!secretKey) {
    throw new Error("Could not retrieve Paystack secret key.");
  }

  return secretKey;
};

/* ==========================================================
   GENERATE DELIVERY VERIFICATION CODE
========================================================== */

const generateVerificationCode = () => {
  return crypto.randomInt(0, 1000000).toString().padStart(6, "0");
};

/* ==========================================================
   GENERATE RECIPIENT TRACKING TOKEN
========================================================== */

const generateRecipientTrackingToken = () => {
  return crypto.randomBytes(24).toString("hex");
};

/* ==========================================================
   GRAPHQL REQUEST
========================================================== */

const graphqlRequest = async (
  query,
  variables = {},
  operationName = "GraphQL operation",
) => {
  if (!GRAPHQL_ENDPOINT) {
    throw new Error("Atua GraphQL endpoint is not configured.");
  }

  if (!GRAPHQL_API_KEY) {
    throw new Error("Atua GraphQL API key is not configured.");
  }

  const endpoint = new URL(GRAPHQL_ENDPOINT);

  const body = JSON.stringify({
    query,
    variables,
  });

  const options = {
    hostname: endpoint.hostname,

    path: endpoint.pathname || "/graphql",

    method: "POST",

    headers: {
      "Content-Type": "application/json",

      "Content-Length": Buffer.byteLength(body),

      "x-api-key": GRAPHQL_API_KEY,
    },
  };

  return new Promise((resolve, reject) => {
    const request = https.request(options, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          console.error(`${operationName} HTTP ERROR:`, {
            statusCode: res.statusCode,

            body: data,
          });

          return reject(
            new Error(`${operationName} returned HTTP ${res.statusCode}.`),
          );
        }

        let parsed;

        try {
          parsed = JSON.parse(data);
        } catch (error) {
          console.error(`${operationName} JSON PARSE ERROR:`, {
            error: error.message,

            response: data,
          });

          return reject(error);
        }

        if (parsed?.errors?.length) {
          console.error(
            `${operationName} GRAPHQL ERRORS:`,
            JSON.stringify(parsed.errors),
          );

          return reject(
            new Error(
              parsed.errors
                .map((item) => item?.message)
                .filter(Boolean)
                .join(" | ") || `${operationName} failed.`,
            ),
          );
        }

        resolve(parsed?.data || null);
      });
    });

    request.on("error", (error) => {
      console.error(`${operationName} REQUEST ERROR:`, error);

      reject(error);
    });

    request.write(body);

    request.end();
  });
};

/* ==========================================================
   COMPLETE ORDER FIELDS
========================================================== */

const ORDER_FIELDS = `
  id

  recipientName
  recipientNumber
  recipientNumber2
  orderDetails

  originAddress
  originState
  originLat
  originLng

  destinationAddress
  destinationState
  destinationLat
  destinationLng

  tripType
  distance

  transportationType
  vehicleClass
  orderEnvironment

  status

  hasNewOffer
  lastOfferAt
  lastOfferSenderType

  loadCategory
  isInterState

  estimatedMinPrice
  estimatedMaxPrice
  initialOfferPrice

  loadingFee
  unloadingFee
  floorSurcharge
  fragileSurcharge
  extrasTotal

  totalPrice
  operationalFare

  courierEarnings
  commissionAmount
  platformFee
  platformServiceRevenue
  vatAmount
  platformNetRevenue

  deliveryVerificationCode

  recipientTrackingToken
  recipientTrackingEnabled
  recipientTrackingRevokedAt

  declaredWeightBracket

  senderPreTransferPhotos
  senderPreTransferVideo
  senderPreTransferRecordedAt

  senderPreTransferLocalPhotos
  senderPreTransferLocalVideo

  mediaUploadStatus

  courierPreTransferUploadStatus
  courierPostLoadingUploadStatus
  dropoffUploadStatus

  courierPreTransferPhotos
  courierPreTransferVideo
  courierPreTransferRecordedAt

  courierPreTransferLocalPhotos
  courierPreTransferLocalVideo

  courierPostLoadingPhotos
  courierPostLoadingVideo

  courierPostLoadingLocalPhotos
  courierPostLoadingLocalVideo

  dropoffArrivalPhotos
  dropoffArrivalVideo

  dropoffArrivalLocalPhotos
  dropoffArrivalLocalVideo

  postDeliveryPhotos
  postDeliveryVideo

  pickupLoadingResponsibility
  pickupFloorLevel
  pickupFloorLevelPrice
  pickupHasElevator

  dropoffUnloadingResponsibility
  dropoffFloorLevel
  dropoffFloorLevelPrice
  dropoffHasElevator

  acceptedAt
  arrivedPickupAt
  loadingStartedAt
  tripStartedAt
  arrivedDropoffAt
  unloadingCompletedAt

  logisticsCompanyId
  waybillNumber
  waybillPhoto
  logisticsTrackingCode
  logisticsTrackingStatus
  handedOverToLogisticsAt
  logisticsIntakeConfirmedAt

  acceptedOfferID

  paymentStatus
  paymentID
  paymentReference

  payoutStatus
  fundsStatus

  earningsAllocationStatus
  earningsAllocatedAt

  fundsReleaseBlocked
  fundsHoldReason
  fundsHeldBy
  fundsHeldAt
  fundsReleasedAmount
  pickupFundsReleasedAt
  fundsReleasedAt
  fundsReleaseType

  assignedCourierId
  assignmentExpiresAt
  assignmentAttempts
  lastAssignedAt
  rejectedCourierIds
  assignmentStatus

  # MAXI capacity idempotency marker
  maxiCountIncrementedAt

  userID

  bookingSource
  paymentResponsibility
  paymentTiming
  paymentMethod
  supportCreatedByID
  receiverConfirmationStatus
  receiverConfirmedAt
  receiverPaymentExpiresAt

  createdAt
  updatedAt

  _version
  _lastChangedAt
  _deleted
`;

/* ==========================================================
   GET ORDER
========================================================== */

const getOrder = async (orderId) => {
  if (!orderId) {
    throw new Error("Order ID is required.");
  }

  const query = `
    query GetOrder(
      $id: ID!
    ) {
      getOrder(
        id: $id
      ) {
        ${ORDER_FIELDS}
      }
    }
  `;

  const data = await graphqlRequest(
    query,
    {
      id: orderId,
    },
    "GetOrder",
  );

  return data?.getOrder || null;
};

/* ==========================================================
   GET COURIER FOR MAXI COUNT
========================================================== */

/*
 * Gets the exact courier assigned to this MAXI Order.
 *
 * IMPORTANT:
 * We use assignedCourierId from the Order.
 *
 * We do NOT search for another available courier.
 * The courier whose accepted bid caused the Order to become
 * ACCEPTED is the courier whose MAXI capacity must increase.
 */

const getCourierForMaxiCount = async (courierId) => {
  if (!courierId) {
    throw new Error("Courier ID is required for MAXI count update.");
  }

  const query = `
    query GetCourier(
      $id: ID!
    ) {
      getCourier(
        id: $id
      ) {
        id
        currentMaxiCount
        _version
        _lastChangedAt
        _deleted
      }
    }
  `;

  const data = await graphqlRequest(
    query,
    {
      id: courierId,
    },
    "GetCourierForMaxiCount",
  );

  const courier = data?.getCourier || null;

  if (!courier || courier._deleted) {
    throw new Error(`Assigned MAXI courier ${courierId} could not be found.`);
  }

  return courier;
};

/* ==========================================================
   INCREMENT MAXI COURIER COUNT
========================================================== */

/*
 * Increments currentMaxiCount for the courier assigned to
 * this MAXI Order.
 *
 * This function is intentionally idempotent at the Order level.
 *
 * Once maxiCountIncrementedAt has been saved on the Order,
 * subsequent webhook / verifyAtuaPayment retries will NOT
 * increment the courier again.
 *
 * Micro and Moto Orders are completely ignored.
 */

const incrementMaxiCourierCount = async (order) => {
  if (!order?.id) {
    throw new Error("Order is required for MAXI count update.");
  }

  /*
   * Only MAXI Orders use currentMaxiCount.
   *
   * Micro and Moto must never enter this logic.
   */
  if (order.transportationType !== "MAXI") {
    return order;
  }

  /*
   * If this Order has already caused the courier's MAXI count
   * to increase, do nothing.
   *
   * This protects against webhook retries and verifyAtuaPayment
   * being called more than once.
   */
  if (order.maxiCountIncrementedAt) {
    console.log("MAXI COUNT ALREADY INCREMENTED:", {
      orderID: order.id,
      maxiCountIncrementedAt: order.maxiCountIncrementedAt,
    });

    return order;
  }

  /*
   * A MAXI Order must already have an assigned courier before
   * payment can increase that courier's active MAXI count.
   */
  if (!order.assignedCourierId) {
    throw new Error(
      `MAXI Order ${order.id} has no assignedCourierId. ` +
        "Cannot increment MAXI courier count.",
    );
  }

  console.log("PREPARING MAXI COURIER COUNT INCREMENT:", {
    orderID: order.id,
    assignedCourierId: order.assignedCourierId,
    currentMaxiCountMarker: order.maxiCountIncrementedAt || null,
  });

  /*
   * Get the exact assigned courier.
   */
  const courier = await getCourierForMaxiCount(order.assignedCourierId);

  const currentMaxiCount = Number(courier.currentMaxiCount || 0);

  if (!Number.isFinite(currentMaxiCount) || currentMaxiCount < 0) {
    throw new Error(
      `Invalid currentMaxiCount for courier ${courier.id}: ` +
        `${courier.currentMaxiCount}`,
    );
  }

  const nextMaxiCount = currentMaxiCount + 1;

  /*
   * Update the Courier.
   *
   * We include _version because this is an Amplify/DataStore
   * backed model using optimistic concurrency.
   */
  const courierMutation = `
    mutation UpdateCourier(
      $input: UpdateCourierInput!
    ) {
      updateCourier(
        input: $input
      ) {
        id
        currentMaxiCount
        _version
        _lastChangedAt
        _deleted
      }
    }
  `;

  const courierInput = {
    id: courier.id,
    currentMaxiCount: nextMaxiCount,
  };

  if (Number.isInteger(courier._version)) {
    courierInput._version = courier._version;
  }

  console.log("INCREMENTING MAXI COURIER COUNT:", {
    courierID: courier.id,
    previousCount: currentMaxiCount,
    nextCount: nextMaxiCount,
    orderID: order.id,
  });

  const courierData = await graphqlRequest(
    courierMutation,
    {
      input: courierInput,
    },
    "UpdateCourierMaxiCount",
  );

  const updatedCourier = courierData?.updateCourier || null;

  if (!updatedCourier) {
    throw new Error(
      `MAXI courier count update returned no Courier for ${courier.id}.`,
    );
  }

  /*
   * Now mark the Order so that retries do not increment the
   * same courier again.
   */
  const orderMutation = `
    mutation UpdateOrder(
      $input: UpdateOrderInput!
    ) {
      updateOrder(
        input: $input
      ) {
        ${ORDER_FIELDS}
      }
    }
  `;

  const maxiCountIncrementedAt = new Date().toISOString();

  const orderInput = {
    id: order.id,
    maxiCountIncrementedAt,
  };

  if (Number.isInteger(order._version)) {
    orderInput._version = order._version;
  }

  console.log("MARKING MAXI COUNT INCREMENTED:", {
    orderID: order.id,
    courierID: updatedCourier.id,
    maxiCountIncrementedAt,
    currentOrderVersion: order._version,
  });

  const orderData = await graphqlRequest(
    orderMutation,
    {
      input: orderInput,
    },
    "MarkMaxiCountIncremented",
  );

  const updatedOrder = orderData?.updateOrder || null;

  if (!updatedOrder) {
    throw new Error(
      `MAXI count marker update returned no Order for ${order.id}.`,
    );
  }

  console.log("MAXI COURIER COUNT INCREMENTED SUCCESSFULLY:", {
    orderID: updatedOrder.id,
    courierID: updatedCourier.id,
    previousCount: currentMaxiCount,
    newCount: updatedCourier.currentMaxiCount,
    maxiCountIncrementedAt: updatedOrder.maxiCountIncrementedAt,
  });

  /*
   * Return the updated Order so the caller can continue using
   * the newest Order state.
   */
  return updatedOrder;
};

/* ==========================================================
   GET PAYMENT BY REFERENCE
========================================================== */

const getPaymentByReference = async (reference) => {
  if (!reference) {
    throw new Error("Payment reference is required.");
  }

  const query = `
    query ListPayments(
      $filter: ModelPaymentFilterInput
    ) {
      listPayments(
        filter: $filter
        limit: 1
      ) {
        items {
          id

          orderID
          userID

          amount
          currency

          status
          paymentMethod
          provider

          reference

          createdAt
          updatedAt

          _version
          _lastChangedAt
          _deleted
        }
      }
    }
  `;

  const data = await graphqlRequest(
    query,
    {
      filter: {
        reference: {
          eq: reference,
        },
      },
    },
    "GetPaymentByReference",
  );

  return data?.listPayments?.items?.find((item) => !item?._deleted) || null;
};

/* ==========================================================
   MARK VERIFIED PAYMENT AS SUCCESSFUL
========================================================== */

const markPaymentAsSuccessful = async ({ payment, order, transaction }) => {
  if (!payment?.id || !order?.id || !transaction?.reference) {
    throw new Error("Payment, Order, or transaction reference is missing.");
  }

  // Ensure this Payment belongs to this exact Order and user.
  if (
    payment.orderID !== order.id ||
    payment.userID !== order.userID ||
    payment.reference !== transaction.reference ||
    payment.provider !== "PAYSTACK"
  ) {
    throw new Error(
      "Payment does not match the verified Order and transaction.",
    );
  }

  const expectedAmount = Number(order.totalPrice);
  const recordedAmount = Number(payment.amount);
  const expectedAmountInKobo = Math.round(expectedAmount * 100);

  if (
    transaction.status !== "success" ||
    transaction.currency !== "NGN" ||
    payment.currency !== "NGN" ||
    !Number.isFinite(recordedAmount) ||
    recordedAmount !== expectedAmount ||
    Number(transaction.amount) !== expectedAmountInKobo
  ) {
    throw new Error(
      "Payment amount, currency, or transaction status is invalid.",
    );
  }

  if (payment.status === "SUCCESS") {
    return payment;
  }

  if (payment.status !== "PENDING") {
    throw new Error(`Cannot finalize Payment with status: ${payment.status}`);
  }

  const mutation = `
    mutation MarkPaymentAsSuccessful($input: UpdatePaymentInput!) {
      updatePayment(input: $input) {
        id
        orderID
        userID
        amount
        currency
        status
        paymentMethod
        provider
        reference
        paidAt
        updatedAt
        _version
        _lastChangedAt
        _deleted
      }
    }
  `;

  const input = {
    id: payment.id,
    status: "SUCCESS",
    paidAt: transaction.paid_at || new Date().toISOString(),
  };

  if (Number.isInteger(payment._version)) {
    input._version = payment._version;
  }

  const data = await graphqlRequest(
    mutation,
    { input },
    "MarkPaymentAsSuccessful",
  );

  const updatedPayment = data?.updatePayment;

  if (
    !updatedPayment ||
    updatedPayment.id !== payment.id ||
    updatedPayment.status !== "SUCCESS" ||
    updatedPayment.reference !== transaction.reference
  ) {
    throw new Error(
      "Payment could not be confirmed as SUCCESS in the database.",
    );
  }

  console.log("PAYMENT MARKED SUCCESSFUL:", {
    paymentID: updatedPayment.id,
    orderID: updatedPayment.orderID,
    reference: updatedPayment.reference,
    status: updatedPayment.status,
  });

  return updatedPayment;
};

/* ==========================================================
   CREATE PAYMENT
========================================================== */

const createPayment = async ({ order, transaction }) => {
  if (!order?.id) {
    throw new Error("Order is required to create Payment.");
  }

  if (!order?.userID) {
    throw new Error(`Order ${order.id} has no userID.`);
  }

  if (!transaction?.reference) {
    throw new Error("Paystack transaction reference is required.");
  }

  const amount = Number(order.totalPrice);

  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error(`Invalid Order totalPrice: ${order.totalPrice}`);
  }

  const mutation = `
    mutation CreatePayment(
      $input: CreatePaymentInput!
    ) {
      createPayment(
        input: $input
      ) {
        id

        orderID
        userID

        amount
        currency

        status
        paymentMethod
        provider

        reference

        createdAt
        updatedAt

        _version
        _lastChangedAt
        _deleted
      }
    }
  `;

  const input = {
    orderID: order.id,

    userID: order.userID,

    amount,

    currency: transaction.currency || "NGN",

    status: "SUCCESS",

    paymentMethod: transaction.channel || "paystack",

    provider: "PAYSTACK",

    reference: transaction.reference,
  };

  console.log("CREATING FALLBACK PAYMENT:", {
    orderID: input.orderID,

    userID: input.userID,

    amount: input.amount,

    reference: input.reference,
  });

  const data = await graphqlRequest(
    mutation,
    {
      input,
    },
    "CreatePayment",
  );

  const payment = data?.createPayment || null;

  if (!payment) {
    throw new Error("Payment creation returned no Payment.");
  }

  console.log("FALLBACK PAYMENT CREATED:", {
    paymentID: payment.id,

    orderID: payment.orderID,

    userID: payment.userID,

    reference: payment.reference,
  });

  return payment;
};

/* ==========================================================
   FALLBACK ORDER UPDATE
========================================================== */

/*
 * This function is ONLY called when:
 *
 *     Paystack says SUCCESS
 *
 * AND
 *
 *     the webhook has not successfully completed
 *     the Order.
 *
 * It is NOT called merely because verifyAtuaPayment
 * was invoked.
 */

const markOrderAsPaidFallback = async ({
  order,
  paymentId,
  paymentReference,
  verificationCode,
  recipientTrackingToken,
}) => {
  if (!order?.id) {
    throw new Error("Order is required before fallback update.");
  }

  if (!order?.userID) {
    throw new Error(`Order ${order.id} is missing userID.`);
  }

  if (!paymentId) {
    throw new Error("Payment ID is required.");
  }

  if (!verificationCode) {
    throw new Error("Delivery verification code is required.");
  }

  if (!recipientTrackingToken) {
    throw new Error("Recipient tracking token is required.");
  }

  const mutation = `
    mutation UpdateOrder(
      $input: UpdateOrderInput!
    ) {
      updateOrder(
        input: $input
      ) {
        ${ORDER_FIELDS}
      }
    }
  `;

  /*
   * --------------------------------------------------------
   * PAYMENT FINALIZATION STATUS
   * --------------------------------------------------------
     /*
   * Preserve the existing payment-before-pickup behaviour:
   *   MAXI       -> ACCEPTED
   *   MICRO/MOTO -> READY_FOR_PICKUP
   *
   * For payment on delivery, do not reset the order's status.
   * The order may already be in transit or awaiting delivery.
   */
  const paymentFinalizedStatus =
    String(order.paymentTiming || "BEFORE_PICKUP")
      .trim()
      .toUpperCase() === "ON_DELIVERY"
      ? order.status
      : order.transportationType === "MAXI"
        ? "ACCEPTED"
        : "READY_FOR_PICKUP";

  const input = {
    id: order.id,

    orderEnvironment: order.orderEnvironment,

    userID: order.userID,

    paymentStatus: "PAID",

    paymentID: paymentId,

    paymentReference,

    status: paymentFinalizedStatus,

    fundsStatus: "HELD",

    earningsAllocationStatus: "NOT_ALLOCATED",

    deliveryVerificationCode: verificationCode,

    // Enable recipient tracking when payment is successfully confirmed.
    recipientTrackingToken,

    recipientTrackingEnabled: true,

    // The field is nullable and should be clear for a fresh payment.
    recipientTrackingRevokedAt: null,
  };

  if (Number.isInteger(order._version)) {
    input._version = order._version;
  }

  console.log("FALLBACK ORDER UPDATE:", {
    orderID: order.id,

    orderEnvironment: order.orderEnvironment,

    userID: order.userID,

    currentVersion: order._version,

    paymentID: paymentId,

    paymentStatus: "PAID",

    status: paymentFinalizedStatus,

    fundsStatus: "HELD",

    verificationCode,
    recipientTrackingToken,
    recipientTrackingEnabled: true,
    recipientTrackingRevokedAt: null,
  });

  const data = await graphqlRequest(
    mutation,
    {
      input,
    },
    "MarkOrderAsPaidFallback",
  );

  const updatedOrder = data?.updateOrder || null;

  if (!updatedOrder) {
    throw new Error("Fallback Order update returned no Order.");
  }

  console.log(
    "FALLBACK ORDER UPDATED:",
    JSON.stringify(
      {
        id: updatedOrder.id,

        orderEnvironment: updatedOrder.orderEnvironment,

        userID: updatedOrder.userID,

        paymentStatus: updatedOrder.paymentStatus,

        paymentID: updatedOrder.paymentID,

        fundsStatus: updatedOrder.fundsStatus,

        status: updatedOrder.status,

        deliveryVerificationCode: updatedOrder.deliveryVerificationCode,

        totalPrice: updatedOrder.totalPrice,

        recipientName: updatedOrder.recipientName,

        originAddress: updatedOrder.originAddress,

        destinationAddress: updatedOrder.destinationAddress,

        _version: updatedOrder._version,

        _lastChangedAt: updatedOrder._lastChangedAt,
      },
      null,
      2,
    ),
  );

  return updatedOrder;
};

/* ==========================================================
   VERIFY TRANSACTION WITH PAYSTACK
========================================================== */

const verifyWithPaystack = async (reference, secretKey) => {
  if (!reference) {
    throw new Error("Payment reference is required.");
  }

  const encodedReference = encodeURIComponent(reference);

  const options = {
    hostname: "api.paystack.co",

    path: `/transaction/verify/${encodedReference}`,

    method: "GET",

    headers: {
      Authorization: `Bearer ${secretKey}`,

      Accept: "application/json",
    },
  };

  return new Promise((resolve, reject) => {
    const request = https.request(options, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", () => {
        let parsed;

        try {
          parsed = JSON.parse(data);
        } catch (error) {
          console.error("PAYSTACK RESPONSE PARSE ERROR:", {
            statusCode: res.statusCode,

            body: data,
          });

          return reject(error);
        }

        resolve({
          statusCode: res.statusCode,

          body: parsed,
        });
      });
    });

    request.on("error", (error) => {
      console.error("PAYSTACK REQUEST ERROR:", error);

      reject(error);
    });

    request.end();
  });
};

/* ==========================================================
   FAILURE RESULT
========================================================== */

const failureResult = (message, orderId = null) => {
  return {
    success: false,

    verified: false,

    alreadyPaid: false,

    fallbackUsed: false,

    message,

    orderId,

    deliveryVerificationCode: null,

    payment: null,
  };
};

/* ==========================================================
   PAYMENT DETAILS
========================================================== */

const buildPaymentDetails = ({
  reference,
  amount,
  currency,
  status,
  channel,
  paidAt,
}) => {
  return {
    reference: reference || null,

    amount: Number(amount),

    currency: currency || null,

    status: status || null,

    channel: channel || null,

    paidAt: paidAt || null,
  };
};

/**
 * ---------------------------------------------------------
 * SAVE REUSABLE PAYSTACK PAYMENT METHOD
 * ---------------------------------------------------------
 *
 * This helper is intentionally NON-FATAL.
 *
 * The payment has already been confirmed successfully.
 * Therefore, if saving the card fails, we must NOT turn
 * the successful payment into a failed payment.
 *
 * This is also safe to call multiple times because
 * paymentMethodHelper.js uses the Paystack card signature
 * to make the operation idempotent.
 * ---------------------------------------------------------
 */
async function savePaymentMethodIfReusable({
  order,
  transaction,
  paystackSecretKey,
}) {
  try {
    const authorization = transaction?.authorization;

    // Only save reusable Paystack authorizations.
    if (
      !authorization ||
      authorization.reusable !== true ||
      !authorization.authorization_code ||
      !authorization.signature
    ) {
      console.log(
        "PAYMENT METHOD NOT SAVED: Transaction has no reusable authorization.",
        {
          orderId: order?.id,
          hasAuthorization: !!authorization,
          reusable: authorization?.reusable,
          hasAuthorizationCode: !!authorization?.authorization_code,
          hasSignature: !!authorization?.signature,
        },
      );

      return;
    }

    // Paystack normally provides the customer's email here.
    const customerEmail =
      transaction?.customer?.email ||
      transaction?.customer?.customer_email ||
      transaction?.email ||
      null;

    if (!customerEmail) {
      console.log("PAYMENT METHOD NOT SAVED: Customer email unavailable.", {
        orderId: order?.id,
      });

      return;
    }

    if (!order?.userID) {
      console.log("PAYMENT METHOD NOT SAVED: Order has no userID.", {
        orderId: order?.id,
      });

      return;
    }

    const result = await saveReusablePaymentMethod({
      endpoint: GRAPHQL_ENDPOINT,
      region: REGION,
      userID: order.userID,
      authorization,
      email: customerEmail,
      paystackSecretKey,
    });

    console.log("PAYMENT METHOD SAVE RESULT:", {
      orderId: order.id,
      userID: order.userID,
      saved: result?.saved,
      created: result?.created,
      reactivated: result?.reactivated || false,
      paymentMethodId: result?.paymentMethod?.id || null,
      last4: result?.paymentMethod?.last4 || null,
    });
  } catch (error) {
    // VERY IMPORTANT:
    // Never fail an already-successful payment because the
    // saved-card operation failed.
    console.error("SAVE PAYMENT METHOD ERROR:", {
      orderId: order?.id,
      userID: order?.userID,
      error: error?.message || error,
    });
  }
}

/* ==========================================================
   VERIFY ATUA PAYMENT
========================================================== */

/*
 * ==========================================================
 *
 * PAYMENT ARCHITECTURE
 *
 * ==========================================================
 *
 * PRIMARY:
 *
 * Paystack
 *    ↓
 * charge.success webhook
 *    ↓
 * paystackWebhook
 *    ↓
 * Payment
 *    ↓
 * Order:
 *    PAID
 *    HELD
 *
 *    MICRO / MOTO:
 *    READY_FOR_PICKUP
 *
 *    MAXI:
 *    ACCEPTED
 *
 *    deliveryVerificationCode
 *
 *
 * FALLBACK:
 *
 * verifyAtuaPayment
 *    ↓
 * verify Paystack directly
 *    ↓
 * reload Order
 *
 *    ┌─────────────────────────────────────┐
 *    │                                     │
 *    │ PAID + CODE                         │
 *    │                                     │
 *    │      → DO NOTHING                   │
 *    │      → return success               │
 *    │                                     │
 *    └─────────────────────────────────────┘
 *
 *
 *    ┌─────────────────────────────────────┐
 *    │                                     │
 *    │ PAID + NO CODE                      │
 *    │                                     │
 *    │      → WEBHOOK PAYMENT SUCCEEDED    │
 *    │      → BUT CODE IS MISSING          │
 *    │      → GENERATE CODE                │
 *    │      → UPDATE ONLY CODE + REQUIRED  │
 *    │        PAYMENT FIELDS               │
 *    │                                     │
 *    └─────────────────────────────────────┘
 *
 *
 *    ┌─────────────────────────────────────┐
 *    │                                     │
 *    │ NOT PAID                            │
 *    │                                     │
 *    │      → verify Paystack              │
 *    │      → create/find Payment           │
 *    │      → generate code                │
 *    │      → fallback Order update        │
 *    │                                     │
 *    └─────────────────────────────────────┘
 *
 * ==========================================================
 */

/* ==========================================================
   REPAIR DELIVERY CODE AND RECIPIENT TRACKING DATA
========================================================== */

/*
 * This is different from markOrderAsPaidFallback().
 *
 * It is used for the very specific case:
 *
 *     Order.paymentStatus === "PAID"
 *
 * AND
 *
 *     Order.deliveryVerificationCode or recipient tracking data is missing
 *
 * In that situation the webhook already processed the
 * payment, so we DO NOT change payment status, Payment ID,
 * funds status, etc.
 *
 * We only repair the missing delivery or recipient tracking data.
 *
 * This prevents verifyAtuaPayment from becoming a second
 * payment processor.
 */

const repairMissingVerificationCode = async ({
  order,
  verificationCode,
  recipientTrackingToken,
}) => {
  if (!order?.id) {
    throw new Error(
      "Order is required to repair delivery and recipient tracking data.",
    );
  }

  if (!order?.userID) {
    throw new Error(`Order ${order.id} is missing userID.`);
  }

  if (!verificationCode) {
    throw new Error("Verification code is required.");
  }

  if (!recipientTrackingToken) {
    throw new Error("Recipient tracking token is required.");
  }

  const mutation = `
    mutation UpdateOrder(
      $input: UpdateOrderInput!
    ) {
      updateOrder(
        input: $input
      ) {
        ${ORDER_FIELDS}
      }
    }
  `;

  const input = {
    id: order.id,

    orderEnvironment: order.orderEnvironment,

    /*
     * Keep required userID present.
     */
    userID: order.userID,

    /*
     * Payment is already PAID.
     *
     * We preserve these existing values instead of
     * inventing new payment information.
     */
    paymentStatus: order.paymentStatus,

    paymentID: order.paymentID,

    fundsStatus: order.fundsStatus,

    status: order.status,

    deliveryVerificationCode: verificationCode,

    // Repair or restore recipient tracking fields as well.
    recipientTrackingToken,

    recipientTrackingEnabled: true,

    recipientTrackingRevokedAt: null,
  };

  if (Number.isInteger(order._version)) {
    input._version = order._version;
  }

  console.log("REPAIRING DELIVERY AND RECIPIENT TRACKING DATA:", {
    orderID: order.id,
    userID: order.userID,
    currentVersion: order._version,
    paymentStatus: order.paymentStatus,
    paymentID: order.paymentID,
    fundsStatus: order.fundsStatus,
    status: order.status,
    verificationCode,
    recipientTrackingToken,
    recipientTrackingEnabled: true,
    recipientTrackingRevokedAt: null,
  });

  const data = await graphqlRequest(
    mutation,
    {
      input,
    },
    "RepairMissingVerificationCode",
  );

  const updatedOrder = data?.updateOrder || null;

  if (!updatedOrder) {
    throw new Error("Verification code repair returned no Order.");
  }

  console.log(
    "VERIFICATION CODE REPAIR RESULT:",
    JSON.stringify(
      {
        id: updatedOrder.id,

        orderEnvironment: updatedOrder.orderEnvironment,

        userID: updatedOrder.userID,

        paymentStatus: updatedOrder.paymentStatus,

        paymentID: updatedOrder.paymentID,

        fundsStatus: updatedOrder.fundsStatus,

        status: updatedOrder.status,

        deliveryVerificationCode: updatedOrder.deliveryVerificationCode,

        recipientTrackingToken: updatedOrder.recipientTrackingToken,

        recipientTrackingEnabled: updatedOrder.recipientTrackingEnabled,

        recipientTrackingRevokedAt: updatedOrder.recipientTrackingRevokedAt,

        recipientName: updatedOrder.recipientName,

        originAddress: updatedOrder.originAddress,

        destinationAddress: updatedOrder.destinationAddress,

        totalPrice: updatedOrder.totalPrice,

        courierEarnings: updatedOrder.courierEarnings,

        _version: updatedOrder._version,

        _lastChangedAt: updatedOrder._lastChangedAt,
      },
      null,
      2,
    ),
  );

  return updatedOrder;
};

/* ==========================================================
   REPAIR MISSING ORDER PAYMENT REFERENCE
========================================================== */

const repairMissingPaymentReference = async ({
  order,
  payment,
  transaction,
}) => {
  if (!order?.id || !order?.userID) {
    throw new Error("Order identity is missing.");
  }

  if (!payment?.id) {
    throw new Error("Verified Payment record is missing.");
  }

  const reference = transaction?.reference;

  // Validate that the stored Payment belongs to this exact Order.
  if (payment.orderID !== order.id || payment.userID !== order.userID) {
    throw new Error("Payment record does not match this Order and user.");
  }

  if (
    payment.reference !== reference ||
    transaction.status !== "success" ||
    payment.status !== "SUCCESS"
  ) {
    throw new Error(
      "Payment reference or payment status could not be verified.",
    );
  }

  const expectedAmount = Number(order.totalPrice);
  const paymentAmount = Number(payment.amount);

  if (
    !Number.isFinite(paymentAmount) ||
    paymentAmount !== expectedAmount ||
    payment.currency !== "NGN" ||
    transaction.currency !== "NGN" ||
    Number(transaction.amount) !== Math.round(expectedAmount * 100)
  ) {
    throw new Error("Payment amount or currency does not match the Order.");
  }

  if (order.paymentID && order.paymentID !== payment.id) {
    throw new Error(
      "Order paymentID does not match the verified Payment record. Manual review is required.",
    );
  }

  if (payment.provider !== "PAYSTACK") {
    throw new Error("Payment provider is not Paystack.");
  }

  // Never silently replace a different reference.
  if (order.paymentReference) {
    if (order.paymentReference !== reference) {
      throw new Error(
        "Order already has a different payment reference. Manual review is required.",
      );
    }

    return order;
  }

  const mutation = `
    mutation RepairOrderPaymentReference(
      $input: UpdateOrderInput!
    ) {
      updateOrder(input: $input) {
        id
        userID
        paymentStatus
        paymentID
        paymentReference
        orderEnvironment
        _version
      }
    }
  `;

  const input = {
    id: order.id,
    userID: order.userID,
    orderEnvironment: order.orderEnvironment,
    paymentReference: reference,
  };

  if (Number.isInteger(order._version)) {
    input._version = order._version;
  }

  const data = await graphqlRequest(
    mutation,
    { input },
    "RepairOrderPaymentReference",
  );

  const updatedOrder = data?.updateOrder;

  if (!updatedOrder) {
    throw new Error("Order payment reference repair returned no Order.");
  }

  if (
    updatedOrder.id !== order.id ||
    updatedOrder.userID !== order.userID ||
    updatedOrder.paymentReference !== reference
  ) {
    throw new Error(
      "Order payment reference repair failed identity or reference validation.",
    );
  }

  console.log("ORDER PAYMENT REFERENCE REPAIRED:", {
    orderID: updatedOrder.id,
    paymentID: payment.id,
    paymentReference: updatedOrder.paymentReference,
  });

  return updatedOrder;
};

/* ==========================================================
   MAIN HANDLER
========================================================== */

exports.handler = async (event) => {
  console.log("==========================================");

  console.log("VERIFY ATUA PAYMENT STARTED");

  console.log("==========================================");

  try {
    /* ======================================================
       1. GET ARGUMENTS
    ====================================================== */

    const { orderId, reference } = event?.arguments || {};

    if (!orderId) {
      return failureResult("Order ID is required.");
    }

    if (!reference) {
      return failureResult("Payment reference is required.", orderId);
    }

    console.log("VERIFY PAYMENT REQUEST:", {
      orderId,
      reference,
    });

    /* ======================================================
       2. GET ORDER
    ====================================================== */

    let order = await getOrder(orderId);

    if (!order) {
      return failureResult("Order could not be found.", orderId);
    }

    console.log(
      "INITIAL ORDER:",
      JSON.stringify(
        {
          id: order.id,

          userID: order.userID,

          paymentStatus: order.paymentStatus,

          paymentID: order.paymentID,

          fundsStatus: order.fundsStatus,

          status: order.status,

          deliveryVerificationCode: order.deliveryVerificationCode,

          recipientTrackingToken: order.recipientTrackingToken,
          recipientTrackingEnabled: order.recipientTrackingEnabled,
          recipientTrackingRevokedAt: order.recipientTrackingRevokedAt,

          totalPrice: order.totalPrice,

          _version: order._version,
        },
        null,
        2,
      ),
    );

    /* ======================================================
       3. VALIDATE USER ID
    ====================================================== */

    if (!order.userID) {
      return failureResult("Order does not have a user ID.", order.id);
    }

    /* ======================================================
       3A. VALIDATE PAYMENT METHOD, TIMING AND RESPONSIBILITY
    ====================================================== */

    /*
     * Backward compatibility:
     * Older orders may not have the new payment fields.
     * Treat missing values as the old sender-pays-before-pickup
     * Paystack flow so existing orders continue to work.
     *
     * Explicit CASH orders must never be marked PAID by
     * this Paystack verification Lambda.
     */

    const paymentResponsibility = String(
      order.paymentResponsibility || "SENDER",
    )
      .trim()
      .toUpperCase();

    const paymentTiming = String(order.paymentTiming || "BEFORE_PICKUP")
      .trim()
      .toUpperCase();

    const paymentMethod = String(order.paymentMethod || "PAYSTACK")
      .trim()
      .toUpperCase();

    if (paymentMethod !== "PAYSTACK") {
      return failureResult(
        "This order is not configured for Paystack payment verification.",
        order.id,
      );
    }

    const validResponsibility = ["SENDER", "RECEIVER"].includes(
      paymentResponsibility,
    );

    if (!validResponsibility) {
      return failureResult(
        "Invalid payment responsibility for this order.",
        order.id,
      );
    }

    const isBeforePickupPayment =
      paymentTiming === "BEFORE_PICKUP" &&
      ["SENDER", "RECEIVER"].includes(paymentResponsibility);

    const isReceiverPayOnDelivery =
      paymentTiming === "ON_DELIVERY" && paymentResponsibility === "RECEIVER";

    if (!isBeforePickupPayment && !isReceiverPayOnDelivery) {
      return failureResult(
        "This payment timing and responsibility combination is not supported by Paystack verification.",
        order.id,
      );
    }

    console.log("PAYMENT FLOW VALIDATED:", {
      orderID: order.id,
      paymentResponsibility,
      paymentTiming,
      paymentMethod,
    });

    /* ======================================================
       4. VALIDATE ORDER AMOUNT
    ====================================================== */

    const orderAmount = Number(order.totalPrice);

    if (!Number.isFinite(orderAmount) || orderAmount <= 0) {
      return failureResult("Order has an invalid payment amount.", order.id);
    }

    /* ======================================================
       5. GET PAYSTACK SECRET
    ====================================================== */

    const secretKey = await getPaystackSecretKey();

    console.log("PAYSTACK SECRET RETRIEVED");

    /* ======================================================
       6. VERIFY TRANSACTION WITH PAYSTACK
    ====================================================== */

    const paystackResponse = await verifyWithPaystack(reference, secretKey);

    console.log("PAYSTACK HTTP STATUS:", paystackResponse?.statusCode);

    const paystack = paystackResponse?.body;

    if (
      !paystackResponse ||
      paystackResponse.statusCode < 200 ||
      paystackResponse.statusCode >= 300 ||
      !paystack?.status
    ) {
      console.error("PAYSTACK VERIFICATION FAILED:", JSON.stringify(paystack));

      return failureResult(
        paystack?.message || "Payment could not be verified.",
        order.id,
      );
    }

    /* ======================================================
       7. GET TRANSACTION
    ====================================================== */

    const transaction = paystack?.data;

    if (!transaction) {
      return failureResult("Paystack returned no transaction.", order.id);
    }

    /* ======================================================
       8. VERIFY TRANSACTION STATUS
    ====================================================== */

    if (transaction.status !== "success") {
      return failureResult(
        "Payment has not been successfully completed.",
        order.id,
      );
    }

    /* ======================================================
       9. VERIFY REFERENCE
    ====================================================== */

    if (transaction.reference !== reference) {
      console.error("PAYMENT REFERENCE MISMATCH:", {
        requestedReference: reference,

        paystackReference: transaction.reference,
      });

      return failureResult("Payment reference does not match.", order.id);
    }

    /* ======================================================
       10. VERIFY CURRENCY
    ====================================================== */

    if (transaction.currency !== "NGN") {
      return failureResult(
        "Payment currency does not match the order.",
        order.id,
      );
    }

    /* ======================================================
       11. VERIFY AMOUNT
    ====================================================== */

    const expectedAmountInKobo = Math.round(orderAmount * 100);

    const paidAmountInKobo = Number(transaction.amount);

    if (!Number.isFinite(paidAmountInKobo)) {
      return failureResult(
        "Paystack returned an invalid payment amount.",
        order.id,
      );
    }

    if (paidAmountInKobo !== expectedAmountInKobo) {
      console.error("PAYMENT AMOUNT MISMATCH:", {
        orderId: order.id,

        expectedAmountInKobo,

        paidAmountInKobo,
      });

      return failureResult(
        "The amount paid does not match the order total.",
        order.id,
      );
    }

    console.log("PAYSTACK TRANSACTION VERIFIED:", {
      orderId: order.id,

      reference: transaction.reference,

      amount: transaction.amount,

      currency: transaction.currency,

      status: transaction.status,
    });

    /* ======================================================
      12. CHECK EXISTING PAYMENT AND BIND IT TO THIS ORDER
    ====================================================== */

    const verifiedReference = String(transaction.reference || "").trim();
    const orderReference = String(order.paymentReference || "").trim();

    if (verifiedReference !== reference) {
      return failureResult("Payment reference does not match.", order.id);
    }

    let payment = await getPaymentByReference(verifiedReference);

    if (payment) {
      // A Payment record must never be reused for a different order.
      if (payment.orderID !== order.id) {
        console.error("PAYMENT ORDER MISMATCH:", {
          reference: verifiedReference,
          paymentOrderID: payment.orderID,
          requestedOrderID: order.id,
        });

        return failureResult(
          "This payment reference does not belong to this order.",
          order.id,
        );
      }

      // The payment must belong to the same customer recorded on the order.
      if (payment.userID !== order.userID) {
        console.error("PAYMENT USER MISMATCH:", {
          reference: verifiedReference,
          paymentUserID: payment.userID,
          orderUserID: order.userID,
        });

        return failureResult(
          "The payment record does not match this order's customer.",
          order.id,
        );
      }

      // If the order already has a reference, it must match.
      if (orderReference && orderReference !== verifiedReference) {
        return failureResult(
          "This reference is not the current payment reference for this order.",
          order.id,
        );
      }

      console.log("EXISTING PAYMENT MATCHES ORDER:", {
        paymentID: payment.id,
        orderID: order.id,
        reference: verifiedReference,
        status: payment.status,
      });
    } else {
      /*
       * Fallback creation is allowed only if the order already records
       * this exact reference. Never create a Payment merely because
       * Paystack reports a successful transaction for the same amount.
       */
      if (!orderReference || orderReference !== verifiedReference) {
        console.error("UNBOUND PAYMENT REFERENCE:", {
          orderID: order.id,
          orderReference,
          verifiedReference,
        });

        return failureResult(
          "This payment reference is not registered to this order.",
          order.id,
        );
      }

      payment = await createPayment({
        order,
        transaction,
      });

      // Another invocation (for example, the webhook) may have created it
      // between our initial lookup and the create attempt.
      if (!payment?.id) {
        payment = await getPaymentByReference(verifiedReference);
      }

      if (
        !payment?.id ||
        payment.orderID !== order.id ||
        payment.userID !== order.userID ||
        payment.reference !== verifiedReference
      ) {
        throw new Error(
          "The Payment record could not be confirmed against the correct order.",
        );
      }
    }

    /* ======================================================
       12A. MARK VERIFIED PAYMENT AS SUCCESSFUL
    ====================================================== */

    payment = await markPaymentAsSuccessful({
      payment,
      order,
      transaction,
    });

    /* ======================================================
       13. RELOAD ORDER
    ====================================================== */

    /*
     * THIS IS VERY IMPORTANT.
     *
     * The webhook could have updated the Order while this
     * Lambda was verifying Paystack.
     *
     * Therefore we throw away the old Order object and
     * retrieve the newest version.
     */

    order = await getOrder(order.id);

    if (!order) {
      throw new Error("Order could not be reloaded.");
    }

    /* Repair missing payment reference after verification. */
    order = await repairMissingPaymentReference({
      order,
      payment,
      transaction,
    });

    console.log(
      "ORDER AFTER PAYSTACK VERIFICATION:",
      JSON.stringify(
        {
          id: order.id,

          orderEnvironment: order.orderEnvironment,

          userID: order.userID,

          paymentStatus: order.paymentStatus,

          paymentID: order.paymentID,

          fundsStatus: order.fundsStatus,

          status: order.status,

          deliveryVerificationCode: order.deliveryVerificationCode,

          version: order._version,
        },
        null,
        2,
      ),
    );

    /* ======================================================
       14. NORMAL WEBHOOK SUCCESS
    ====================================================== */

    /*
     * CASE 1:
     *
     * Webhook has already processed EVERYTHING.
     *
     * There is nothing for verifyAtuaPayment to change.
     */

    if (
      order.paymentStatus === "PAID" &&
      order.deliveryVerificationCode &&
      order.recipientTrackingToken &&
      order.recipientTrackingEnabled === true
    ) {
      /*
       * The webhook already completed the payment.
       *
       * However, for MAXI Orders we still need to make sure the
       * assigned courier's currentMaxiCount was incremented.
       *
       * incrementMaxiCourierCount() is idempotent because it checks
       * maxiCountIncrementedAt first.
       */
      const countUpdatedOrder = await incrementMaxiCourierCount(order);

      await savePaymentMethodIfReusable({
        order: countUpdatedOrder,
        transaction,
        paystackSecretKey: secretKey,
      });
      console.log("==========================================");

      console.log("WEBHOOK ALREADY COMPLETED PAYMENT.");

      console.log("VERIFICATION CODE ALREADY EXISTS.");

      console.log(
        "MAXI COURIER COUNT VERIFIED/UPDATED:",
        countUpdatedOrder.maxiCountIncrementedAt || null,
      );

      console.log("NO PAYMENT UPDATE WILL BE PERFORMED.");

      console.log("==========================================");

      return {
        success: true,

        verified: true,

        alreadyPaid: true,

        fallbackUsed: false,

        message: "Payment has already been processed by the Paystack webhook.",

        orderId: countUpdatedOrder.id,

        deliveryVerificationCode: countUpdatedOrder.deliveryVerificationCode,

        payment: buildPaymentDetails({
          reference: transaction.reference,

          amount: orderAmount,

          currency: transaction.currency,

          status: transaction.status,

          channel: transaction.channel,

          paidAt: transaction.paid_at,
        }),
      };
    }

    /* ======================================================
       15. PAID BUT DELIVERY OR RECIPIENT TRACKING DATA MISSING
    ====================================================== */

    /*
     * CASE 2:
     *
     * This is the special fallback you requested.
     *
     * The webhook already processed the payment:
     *
     *     paymentStatus = PAID
     *
     * BUT:
     *
     *     deliveryVerificationCode or recipient tracking data is missing
     *
     * Therefore:
     *
     *     DO NOT process payment again.
     *
     *     DO NOT create another Payment.
     *
     *     DO NOT change paymentStatus.
     *
     *     DO NOT change fundsStatus.
     *
     *     DO NOT change status.
     *
     *     ONLY generate/save the missing delivery code
     *      and/or recipient tracking data.
     */

    if (
      order.paymentStatus === "PAID" &&
      (!order.deliveryVerificationCode ||
        !order.recipientTrackingToken ||
        order.recipientTrackingEnabled !== true)
    ) {
      console.log("==========================================");

      console.log(
        "ORDER IS PAID BUT DELIVERY CODE OR RECIPIENT TRACKING DATA IS MISSING.",
      );

      console.log("WEBHOOK PROCESSED PAYMENT.");

      console.log(
        "VERIFY ATUA PAYMENT IS REPAIRING MISSING DELIVERY/TRACKING DATA ONLY.",
      );

      console.log("==========================================");

      const verificationCode =
        order.deliveryVerificationCode || generateVerificationCode();

      const recipientTrackingToken =
        order.recipientTrackingToken || generateRecipientTrackingToken();

      console.log("GENERATED FALLBACK VERIFICATION CODE:", {
        orderId: order.id,

        userID: order.userID,

        currentVersion: order._version,
      });

      const repairedOrder = await repairMissingVerificationCode({
        order,
        verificationCode,
        recipientTrackingToken,
      });

      if (!repairedOrder) {
        throw new Error("Could not repair missing verification code.");
      }

      /*
       * The payment is already PAID.
       *
       * For MAXI Orders, make sure the assigned courier's
       * currentMaxiCount has also been incremented.
       *
       * If the webhook already did it, the helper will simply
       * return without incrementing again.
       */
      const countUpdatedOrder = await incrementMaxiCourierCount(repairedOrder);

      if (!repairedOrder.recipientTrackingToken) {
        throw new Error(
          "Tracking repair completed without a saved recipient tracking token.",
        );
      }

      if (repairedOrder.recipientTrackingEnabled !== true) {
        throw new Error(
          "Tracking repair completed but recipient tracking is not enabled.",
        );
      }

      await savePaymentMethodIfReusable({
        order: countUpdatedOrder,
        transaction,
        paystackSecretKey: secretKey,
      });

      console.log("==========================================");

      console.log("DELIVERY AND RECIPIENT TRACKING REPAIR COMPLETED.");

      console.log("ORDER:", repairedOrder.id);

      console.log(
        "DELIVERY VERIFICATION CODE:",
        repairedOrder.deliveryVerificationCode,
      );
      console.log(
        "RECIPIENT TRACKING TOKEN:",
        repairedOrder.recipientTrackingToken,
      );
      console.log(
        "RECIPIENT TRACKING ENABLED:",
        repairedOrder.recipientTrackingEnabled,
      );

      console.log("VERSION:", repairedOrder._version);

      console.log("==========================================");

      return {
        success: true,

        verified: true,

        alreadyPaid: true,

        fallbackUsed: true,

        message:
          "Payment was already confirmed. Missing delivery or recipient tracking data was repaired.",

        orderId: repairedOrder.id,

        deliveryVerificationCode: repairedOrder.deliveryVerificationCode,

        payment: buildPaymentDetails({
          reference: transaction.reference,

          amount: orderAmount,

          currency: transaction.currency,

          status: transaction.status,

          channel: transaction.channel,

          paidAt: transaction.paid_at,
        }),
      };
    }

    /* ======================================================
       16. FULL FALLBACK PAYMENT PROCESSING
    ====================================================== */

    /*
     * CASE 3:
     *
     * The transaction is genuinely successful,
     * but the webhook has NOT yet marked the Order PAID.
     *
     * Therefore verifyAtuaPayment is allowed to complete
     * the entire payment state as a FALLBACK.
     */

    console.log("==========================================");

    console.log("WEBHOOK HAS NOT COMPLETED ORDER.");

    console.log("VERIFY ATUA PAYMENT IS ACTING AS FULL FALLBACK.");

    console.log("==========================================");

    /*
     * Preserve an existing code if there somehow is one.
     */

    const verificationCode =
      order.deliveryVerificationCode || generateVerificationCode();

    const recipientTrackingToken =
      order.recipientTrackingToken || generateRecipientTrackingToken();

    console.log("FALLBACK VERIFICATION CODE:", {
      orderId: order.id,

      reused: Boolean(order.deliveryVerificationCode),
    });

    /* ======================================================
       17. FALLBACK ORDER UPDATE
    ====================================================== */

    const updatedOrder = await markOrderAsPaidFallback({
      order,

      paymentId: payment.id,

      paymentReference: transaction.reference,

      verificationCode,

      recipientTrackingToken,
    });

    if (!updatedOrder) {
      throw new Error("Fallback Order update failed.");
    }

    /* ======================================================
       18. RELOAD FINAL ORDER
    ====================================================== */

    const finalOrder = await getOrder(order.id);

    if (!finalOrder) {
      throw new Error("Could not reload Order after fallback update.");
    }

    /*
     * --------------------------------------------------------
     * MAXI COURIER COUNT
     * --------------------------------------------------------
     *
     * The fallback payment has now been successfully written.
     *
     * If this is a MAXI Order, increase the active MAXI count
     * for the exact courier who accepted the Order.
     *
     * The helper is idempotent, so if the count was already
     * incremented by the webhook, it will not increment again.
     */
    const countUpdatedOrder = await incrementMaxiCourierCount(finalOrder);

    console.log(
      "FINAL FALLBACK ORDER:",
      JSON.stringify(
        {
          id: countUpdatedOrder.id,

          orderEnvironment: countUpdatedOrder.orderEnvironment,

          userID: countUpdatedOrder.userID,

          paymentStatus: countUpdatedOrder.paymentStatus,

          paymentID: countUpdatedOrder.paymentID,

          fundsStatus: countUpdatedOrder.fundsStatus,

          status: countUpdatedOrder.status,

          deliveryVerificationCode: countUpdatedOrder.deliveryVerificationCode,

          recipientName: countUpdatedOrder.recipientName,

          originAddress: countUpdatedOrder.originAddress,

          destinationAddress: countUpdatedOrder.destinationAddress,

          totalPrice: countUpdatedOrder.totalPrice,

          courierEarnings: countUpdatedOrder.courierEarnings,

          version: countUpdatedOrder._version,

          lastChangedAt: countUpdatedOrder._lastChangedAt,
        },
        null,
        2,
      ),
    );

    /* ======================================================
       19. VALIDATE FINAL STATE
    ====================================================== */

    if (countUpdatedOrder.paymentStatus !== "PAID") {
      throw new Error(
        `Fallback payment update did not produce PAID status. Current: ${countUpdatedOrder.paymentStatus}`,
      );
    }

    if (countUpdatedOrder.paymentID !== payment.id) {
      throw new Error(
        `Fallback payment ID mismatch. Expected ${payment.id}, received ${countUpdatedOrder.paymentID}.`,
      );
    }

    if (countUpdatedOrder.fundsStatus !== "HELD") {
      throw new Error(
        `Fallback fundsStatus mismatch. Current: ${countUpdatedOrder.fundsStatus}`,
      );
    }

    const expectedFallbackStatus =
      String(order.paymentTiming || "BEFORE_PICKUP")
        .trim()
        .toUpperCase() === "ON_DELIVERY"
        ? order.status
        : order.transportationType === "MAXI"
          ? "ACCEPTED"
          : "READY_FOR_PICKUP";

    if (countUpdatedOrder.status !== expectedFallbackStatus) {
      throw new Error(
        `Fallback status mismatch. Expected: ${expectedFallbackStatus}, Current: ${countUpdatedOrder.status}`,
      );
    }

    if (!countUpdatedOrder.deliveryVerificationCode) {
      throw new Error("Fallback verification code was not saved.");
    }

    if (!countUpdatedOrder.recipientTrackingToken) {
      throw new Error("Fallback recipient tracking token was not saved.");
    }

    if (countUpdatedOrder.recipientTrackingEnabled !== true) {
      throw new Error("Fallback recipient tracking was not enabled.");
    }

    if (!countUpdatedOrder.userID) {
      throw new Error("Order userID disappeared during fallback update.");
    }

    if (countUpdatedOrder.orderEnvironment !== order.orderEnvironment) {
      throw new Error(
        `Order ${order.id} orderEnvironment changed unexpectedly. ` +
          `Expected ${order.orderEnvironment}, received ${countUpdatedOrder.orderEnvironment}.`,
      );
    }

    /*
     * MAXI Orders must have a marker after the courier count
     * has been successfully incremented.
     *
     * Micro and Moto Orders do not use this marker.
     */
    if (
      countUpdatedOrder.transportationType === "MAXI" &&
      !countUpdatedOrder.maxiCountIncrementedAt
    ) {
      throw new Error("MAXI courier count was not marked as incremented.");
    }

    await savePaymentMethodIfReusable({
      order: countUpdatedOrder,
      transaction,
      paystackSecretKey: secretKey,
    });

    /* ======================================================
       20. SUCCESS
    ====================================================== */

    console.log("==========================================");

    console.log("VERIFY ATUA PAYMENT FALLBACK COMPLETED");

    console.log("ORDER:", countUpdatedOrder.id);

    console.log("CODE:", countUpdatedOrder.deliveryVerificationCode);

    console.log("VERSION:", countUpdatedOrder._version);

    console.log("==========================================");

    return {
      success: true,

      verified: true,

      alreadyPaid: false,

      fallbackUsed: true,

      message:
        "Payment successfully verified and recorded by fallback verification.",

      orderId: countUpdatedOrder.id,

      deliveryVerificationCode: countUpdatedOrder.deliveryVerificationCode,

      recipientTrackingToken: countUpdatedOrder.recipientTrackingToken,

      recipientTrackingEnabled: countUpdatedOrder.recipientTrackingEnabled,

      recipientTrackingRevokedAt: countUpdatedOrder.recipientTrackingRevokedAt,

      payment: buildPaymentDetails({
        reference: transaction.reference,

        amount: orderAmount,

        currency: transaction.currency,

        status: transaction.status,

        channel: transaction.channel,

        paidAt: transaction.paid_at,
      }),
    };
  } catch (error) {
    console.error("==========================================");

    console.error("VERIFY ATUA PAYMENT ERROR");

    console.error("MESSAGE:", error?.message);

    console.error("STACK:", error?.stack);

    console.error("==========================================");

    return {
      success: false,

      verified: false,

      alreadyPaid: false,

      fallbackUsed: false,

      message:
        error?.message || "Something went wrong while verifying the payment.",

      orderId: event?.arguments?.orderId || null,

      deliveryVerificationCode: null,

      payment: null,
    };
  }
};
